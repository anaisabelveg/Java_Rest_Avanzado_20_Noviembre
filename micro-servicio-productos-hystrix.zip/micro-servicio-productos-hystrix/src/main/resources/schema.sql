create table productos(
	ID integer not null,
	descripcion varchar(255),
	precio double,
	primary key (ID)
);
package es.cetelem.controllers;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import es.cetelem.models.Pedido;
import es.cetelem.models.Producto;
import es.cetelem.services.IPedidoService;

@RestController
public class PedidoController {
	
	//@Autowired
	//@Resource(name = "serviceRestTemplate")
	@Resource(name = "serviceRestFeign")
	private IPedidoService service;
	
	
	// En el caso de recibir una excepcion llamamos al metodo manejarError
	@HystrixCommand(fallbackMethod = "manejarError")
	// http://localhost:8002/buscar/1/cantidad/100
	@GetMapping("/buscar/{id}/cantidad/{cantidad}")
	public Pedido crearPedido(@PathVariable Long id, @PathVariable int cantidad) {
		return service.crearPedido(id, cantidad);
	}
	
	
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "**********************");
		System.out.println(ex.getClass() + "---------------------");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto vacio");
		producto.setPrecio(0);
		
		return new Pedido(producto, cantidad);
	} 

}

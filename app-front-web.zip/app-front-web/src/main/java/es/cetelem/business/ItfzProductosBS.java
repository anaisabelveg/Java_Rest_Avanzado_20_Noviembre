package es.cetelem.business;

import java.util.List;

import es.cetelem.models.Carrito;
import es.cetelem.models.Producto;

public interface ItfzProductosBS {
	
	List<Producto> obtenerTodos();
	
	Producto consultarProducto(Long id);
	
	Carrito consultar(String usuario);
	
	Carrito crear(String usuario);
	
	void agregar(Long id, int cantidad, String usuario);
	
	void eliminar(Long id, String usuario);	

}

package es.cetelem.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import es.cetelem.business.ItfzProductosBS;
import es.cetelem.models.Producto;

@Controller
@RequestMapping("/buscar")
public class BuscarController {
	
	@Autowired
	private ItfzProductosBS productosBS;
	
	//@GetMapping
	@RequestMapping(method = RequestMethod.GET)
	public String mostrarFormulario(Model modelo) {
		modelo.addAttribute("prod", new Producto());
		return "formBuscar";
	}
	
	@PostMapping
	public String procesarFormulario(Producto producto, Model modelo) {
		Producto encontrado = productosBS.consultarProducto(producto.getID());
		
		if (encontrado.getID() == null) {
			modelo.addAttribute("msg", "Ese producto no existe");
			return "mostrarMensaje";
		}
		
		modelo.addAttribute("encontrado", encontrado);
		return "mostrarProducto";
	}

}

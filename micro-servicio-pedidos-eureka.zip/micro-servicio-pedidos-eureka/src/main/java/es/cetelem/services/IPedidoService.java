package es.cetelem.services;

import es.cetelem.models.Pedido;

public interface IPedidoService {
	
	Pedido crearPedido(Long id, int cantidad);

}

package es.cetelem.persistence;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import es.cetelem.models.Carrito;

@RepositoryRestResource(collectionResourceRel = "CARRITOS", path = "carritos")
public interface CarritoDAO extends MongoRepository<Carrito, String>{
	
	// URL para consultar todos los carritos
	// http://localhost:8003/carritos
	
	// Buscar un determinado carrito por id
	// http://localhost:8003/carritos/gyhgvhgv8767657gvhgvhg986765
	
	// Utilizamos los metodos heredados y con las keywords podemos crear metodos personalizados
	// https://docs.spring.io/spring-data/jpa/docs/current-SNAPSHOT/reference/html/#reference
	
	// http://localhost:8003/carritos/search/findByUsuario?usuario=Pepito
	public Carrito findByUsuario(String usuario);
	
	
	// Ejemplos de metodos personalizados
	
	// http://localhost:8003/carritos/search/OrderByImporte
	public List<Carrito> OrderByImporte();
	
	
	// http://localhost:8003/carritos/search/findByImporteBetween?min=100&max=500
	public List<Carrito> findByImporteBetween(double min, double max);
	
	// Si queremos ver todos los metodos personalizados
	// http://localhost:8003/carritos/search

}

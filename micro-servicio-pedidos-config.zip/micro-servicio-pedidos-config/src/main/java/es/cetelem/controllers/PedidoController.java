package es.cetelem.controllers;

import java.util.concurrent.CompletableFuture;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.cetelem.models.Pedido;
import es.cetelem.models.Producto;
import es.cetelem.services.IPedidoService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.timelimiter.annotation.TimeLimiter;

@RestController
public class PedidoController {
	
	//@Autowired
	//@Resource(name = "serviceRestTemplate")
	@Resource(name = "serviceRestFeign")
	private IPedidoService service;
	
	
	// En el caso de recibir una excepcion llamamos al metodo manejarError
	@CircuitBreaker(name = "pedidos", fallbackMethod = "manejarError")
	// http://localhost:8002/buscar/1/cantidad/100
	@GetMapping("/buscar/{id}/cantidad/{cantidad}")
	public Pedido crearPedido(@PathVariable Long id, @PathVariable int cantidad) {
		return service.crearPedido(id, cantidad);
	}
	
	// En el caso de recibir una excepcion llamamos al metodo manejarError
	@CircuitBreaker(name = "pedidos", fallbackMethod = "manejarError2")
	@TimeLimiter(name = "pedidos")
	// http://localhost:8002/buscar2/1/cantidad/100
	@GetMapping("/buscar2/{id}/cantidad/{cantidad}")
	public CompletableFuture<Pedido> crearPedido2(@PathVariable Long id, @PathVariable int cantidad) {
		return CompletableFuture.supplyAsync( () ->  service.crearPedido(id, cantidad));
	}
	
	public CompletableFuture<Pedido> manejarError2(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "**********************");
		System.out.println(ex.getClass() + "---------------------");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto vacio");
		producto.setPrecio(0);
		
		return CompletableFuture.supplyAsync( () -> new Pedido(producto, cantidad));
	}
	
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "**********************");
		System.out.println(ex.getClass() + "---------------------");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto vacio");
		producto.setPrecio(0);
		
		return new Pedido(producto, cantidad);
	} 

}

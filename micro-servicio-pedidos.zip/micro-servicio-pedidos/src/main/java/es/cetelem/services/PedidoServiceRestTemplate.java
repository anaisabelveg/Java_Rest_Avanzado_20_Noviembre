package es.cetelem.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import es.cetelem.models.Pedido;
import es.cetelem.models.Producto;

@Service("serviceRestTemplate")
public class PedidoServiceRestTemplate implements IPedidoService{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		Producto producto = restTemplate.getForObject("http://localhost:8001/buscar/{id}", Producto.class, id);
		return new Pedido(producto, cantidad);
	}

}

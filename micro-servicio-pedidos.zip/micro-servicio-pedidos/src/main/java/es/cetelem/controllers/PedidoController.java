package es.cetelem.controllers;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.cetelem.models.Pedido;
import es.cetelem.services.IPedidoService;

@RestController
public class PedidoController {
	
	//@Autowired
	@Resource(name = "serviceRestTemplate")
	private IPedidoService service;
	
	// http://localhost:8002/buscar/1/cantidad/100
	@GetMapping("/buscar/{id}/cantidad/{cantidad}")
	public Pedido crearPedido(@PathVariable Long id, @PathVariable int cantidad) {
		return service.crearPedido(id, cantidad);
	}

}

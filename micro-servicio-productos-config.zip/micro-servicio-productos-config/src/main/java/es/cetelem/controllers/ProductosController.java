package es.cetelem.controllers;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.cetelem.models.Producto;
import es.cetelem.services.IProductoService;

@RestController
public class ProductosController {
	
	@Autowired
	private IProductoService productoService;
	
	// Con puerto dinamico no funciona
//	@Value("${server.port}")
//	private Integer port;
	
	@Autowired
	private HttpServletRequest request;
	
	// Inyectamos el valor de la propiedad modo del servidor de configuracion
	@Value("${configuration.modo}")
	private String modo;
	
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return productoService.consultarTodos()
				.stream()
				.map(prod -> {
					prod.setPort(request.getLocalPort());
					return prod;
				})
				.collect(Collectors.toList());
	}
	
	// http://localhost:8001/buscar/3
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable Long id) throws InterruptedException {
		
		// Mostrar si estoy en modo desarrollo o produccion
		System.out.println("*****************************");
		System.out.println("Estamos en modo: " + modo);
		System.out.println("*****************************");
		
		Producto producto = productoService.buscarProducto(id);

		// Si no encontramos el producto lanzamos una excepcion
		if (producto == null) {
			throw new RuntimeException("Error al buscar el producto");
		}
	
		// Vamos a probar las llamadas lentas
		// Si paro la ejecucion mas de 2 segundos se considera llamada lenta
		// y se contabiliza como erronea
		if (id.equals(5L)) {
			//Thread.sleep(4_000);
		}
		
		// Probar el timeout de 1 segundo
		if (id.equals(1L)) {
			//Thread.sleep(3_000);
		}
		
		
		producto.setPort(request.getLocalPort());
		return producto;
	}

}











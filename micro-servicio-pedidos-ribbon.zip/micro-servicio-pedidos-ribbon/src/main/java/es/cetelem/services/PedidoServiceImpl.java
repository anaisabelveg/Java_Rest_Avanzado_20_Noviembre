package es.cetelem.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.cetelem.clients.ProductosClienteRest;
import es.cetelem.models.Pedido;
import es.cetelem.models.Producto;

@Service("serviceRestFeign")
public class PedidoServiceImpl implements IPedidoService{
		
	@Autowired
	private ProductosClienteRest clienteFeign;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		// Lanzamos la peticion al micro-servicio-productos para buscar 
		// el producto con ese ID
		Producto producto = clienteFeign.buscar(id);
		return new Pedido(producto, cantidad);
	}

}
